
# Troy's Heartbeat Stock Screener — Web App

This version is designed to be hosted online and opened from an iPhone, iPad, Mac, or Windows computer.

## Easiest free deployment: Streamlit Community Cloud

### 1. Create a free GitHub account
Go to GitHub and create an account.

### 2. Create a new repository
Name it:

`heartbeat-stock-screener`

Choose **Public**, then create the repository.

### 3. Upload these files
Upload:

- `app.py`
- `requirements.txt`

### 4. Deploy on Streamlit Community Cloud
Sign in to Streamlit Community Cloud using GitHub.

Choose **Create app**, then select:

- Repository: `heartbeat-stock-screener`
- Branch: `main`
- Main file path: `app.py`

Click **Deploy**.

After deployment, Streamlit gives you a browser link. Save that link to your iPhone Home Screen.

## Add it to your iPhone Home Screen

1. Open the deployed link in Safari.
2. Tap the Share button.
3. Tap **Add to Home Screen**.
4. Name it **Heartbeat Screener**.

It will then open almost like a regular iPhone app.

## What it screens

- Rising 150-day moving average
- Price above the 150-day moving average
- Tight consolidation/base
- Breakout above the recent range
- At least 2× average volume
- Relative strength versus SPY
- Revenue growth
- EPS growth
- Free-cash-flow margin
- Gross margin
- Institutional ownership
- Insider ownership
- Forward P/E
- Analyst target upside

## Data note

The app uses the free `yfinance` package. Data may be delayed, incomplete, or temporarily unavailable. A paid market-data API would be needed for a more reliable professional product covering thousands of stocks in real time.
